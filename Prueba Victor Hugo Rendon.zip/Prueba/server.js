//code to start Express server
const express = require('express');
const app = express();
const port = 3000;

app.listen(port, function () {
    console.log('listening on ' + port)
});

//MongoDB connection constant
const MongoClient = require('mongodb').MongoClient
const bodyParser = require('body-parser');


//constants that we have to use in the methods, GET, POST, PUT, DELETE
let db;
let collection;
let collectionL;
MongoClient.connect('mongodb://localhost/crud-express', { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
    if (err) return console.error(err)
    console.log('Connected to Database')
    db = client.db('crud-express')
    collection = db.collection('book')
    collectionL = db.collection('library')
});

app.use(bodyParser.json());

//GET for books
app.get('/book', (req, res) => {
    db.collection('book').find().toArray()
        .then(results => {
            res.json(results);
        }).catch(error => console.error(error));
})

//POST for books
app.post('/book', (req, res) => {
    collection.insertOne(req.body)
        .then(result => {
            res.json('successfully created book');
        })
        .catch(error => console.error(error))
})

//PUT for books
app.put('/book/:id', (req, res) => {
    collection.findOneAndUpdate(
        { name: req.params.id },
        {
            $set: {
                name: req.body.name,
                author: req.body.author,
                year: req.body.year,
                editorial: req.body.editorial,
                isbn: req.body.isbn
            }
        },
        {
            upsert: true
        }
    ).then(result => { res.json('successfully updated book') })
        .catch(error => console.error(error))

});

//DELETE for books
app.delete('/book/:id', (req, res) => {
    collection.deleteOne(
        { name: req.params.id }
    )
        .then(result => {
            res.json('Book succcessfully removed')
        })
        .catch(error => console.error(error))
})

//CRUD Library
//GET with filter
app.get('/library/:id', (req, res) => {
    var query = { name: req.params.id };
    db.collection('library').find(query).toArray()
        .then(results => {
            res.json(results);
           
        }).catch(error => console.error(error));
})

//GET for library
app.get('/library', (req, res) => {
    db.collection('library').find().toArray()
        .then(results => {
            res.json(results);
        }).catch(error => console.error(error));
})

//POST for library
app.post('/library', (req, res) => {
    collectionL.insertOne(req.body)
        .then(result => {
            console.log(res);
            res.json('successfully created library');
        })
        .catch(error => console.error(error))
})

//PUT for library
app.put('/library/:id', (req, res) => {
    collectionL.findOneAndUpdate(
        { name: req.params.id },
        {
            $set: {
                name: req.body.name,
                creationDate: req.body.creationDate,
                books: req.body.books,
                state: req.body.state,
            }
        },
        {
            upsert: true
        }
    ).then(result => { res.json('successfully updated library') })
        .catch(error => console.error(error))

});

//DELETE for library
app.delete('/library/:id', (req, res) => {
    collectionL.deleteOne(
        { name: req.params.id }
    )
        .then(result => {
            res.json('library succcessfully removed')
        })
        .catch(error => console.error(error))
})

