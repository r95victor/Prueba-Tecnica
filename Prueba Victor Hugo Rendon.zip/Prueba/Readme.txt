Victor Hugo Rendon Sotelo
Dependency used:
 - npm init
 - npm install express --save
 - npm install nodemon --save-dev
 - npm install body-parser --save
 Run:
 - npm run dev
 Tools used for testing:
 -Postman